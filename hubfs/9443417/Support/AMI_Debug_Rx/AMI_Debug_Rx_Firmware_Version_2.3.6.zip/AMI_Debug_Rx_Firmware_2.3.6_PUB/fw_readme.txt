AMI DEBUG RX FIRMWARE v2.3.6 - 2010-07-13

===

Contents:

fw_readme.txt - This file

AMI_Debug_Rx_FW_ReleaseNotes_PUB.pdf - Firmware release notes for v2.3.6

Firmware - Directory containing the latest firmware release
           (AMI_Debug_Rx_FW_2_3_6.rom)

           For instructions on upgrading the device firmware, please
           refer to page 21 of the User Manual for AMI Debug Rx

===

For product support, visit AMI's website ... http://www.ami.com/amidebugrx
