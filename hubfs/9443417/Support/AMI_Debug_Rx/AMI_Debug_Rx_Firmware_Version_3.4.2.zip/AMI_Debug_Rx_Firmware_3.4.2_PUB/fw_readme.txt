AMI DEBUG RX FIRMWARE v3.4.2 - 2018-04-10

===

Contents:

fw_readme.txt - This file

AMI_Debug_Rx_FW_ReleaseNotes_PUB.pdf - Firmware release notes for v3.4.2

Firmware - Directory containing the latest firmware release
           (AMI_Debug_Rx_FW_3_4_2.rom)

           For instructions on upgrading the device firmware, please
           refer to page 21 of the User Manual for AMI Debug Rx

===
